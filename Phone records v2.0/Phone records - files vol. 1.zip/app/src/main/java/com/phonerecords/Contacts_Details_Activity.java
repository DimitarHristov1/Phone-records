package com.phonerecords;

import static android.Manifest.permission.CALL_PHONE;
import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.READ_MEDIA_AUDIO;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.IBinder;
import android.provider.ContactsContract;
import android.provider.OpenableColumns;
import android.text.Editable;
import android.text.Html;
import android.text.TextWatcher;
import android.util.Base64;
import android.util.Log;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultCaller;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.app.Person;
import androidx.documentfile.provider.DocumentFile;

import com.google.android.material.textfield.TextInputLayout;
import com.phonerecords.Adapter.DataAdapter;
import com.phonerecords.DataModel.Item_Database;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;

public class Contacts_Details_Activity extends AppCompatActivity {
    //Declare the variables that are needed
    ListView contact_list_list_view;
    EditText search_text;
    ImageButton return_menu_button, info_button;
    LinearLayout total_count_layout, search_contact_layout;
    Toolbar toolbar;
    TextView total_count;
    TextInputLayout text_layout_search;
    DatabaseHelper myDb;
    DataAdapter dataAdapter;
    //Declare "builder_for_options" with type "AlertDialog.Builder builder" for the options that user has when he clicks on a record
    AlertDialog.Builder builder_for_options;
    //Declare "builder_for_choice" for confirming the choice before calling
    AlertDialog.Builder builder_for_choice;
    //Declare "myMenu_multi_choice_active" of a type "Menu", so we can access the items from our menu when the multichoice is active
    private static Menu myMenu_multi_choice_active;
    private static ArrayList<Item_Database> dataList, userList;
    //Boolean value to check if action mode is activated
    public static boolean IsActionMode = false;
    //Boolean value to check if action mode was used
    public static boolean UsedActionMode = false;
    //"ActionMode" value used for changing the title of the action mode menu when it is activated
    private static ActionMode action_mode = null;
    //Declare and initialize "CALL_PERMISSION_CODE" variable, which will be used to check the if permission for making a call is granted (it is given a random value)
    private static final int CALL_PERMISSION_CODE = 100;
    //Declare and initialize "CHOOSE_VCF_FILE" variable, which will be used to check if a file is an actual ".vcf" file (it is given a random value)
    private static final int CHOOSE_VCF_FILE = 101;
    //Declare the "number_for_call" with type "String" which we will use with the "onRequestPermissionsResult" method
    private static String number_for_call;
    //Declare the "ID_for_record" String which we will use in the "Edit_Contact_Activity" class
    public static int ID_for_record;
    //Declare the String "search_text_string", which will be used in the "DataAdapter" class
    private static String search_text_string;

    //Method for hiding the user's virtual keyboard
    private void closeKeyboard()
    {
        //Declare and initialize new "View" variable to receive the value of the currently focused view
        View view = this.getCurrentFocus();
        //If the currently focused view is not equal to "null", do the following (this will protect the app from crashing)
        if (view != null) {
            //Declare and nitialize "imm" to be an "InputMethodManager", and to receive the "INPUT_METHOD_SERVICE" as a value, a.k.a. the virtual keyboard on the user's device
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            //Hide the keyboard by using the "hideSoftInputFromWindow()" method on the "imm" variable
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    //Method for making a call when user selects "Call" button from the alert dialog
    private void makeCall(String phoneNumber) {
        Intent intent = new Intent(Intent.ACTION_CALL);
        intent.setData(Uri.parse("tel:" + phoneNumber));
        startActivity(intent);
    }

    //Method to check if there is a given call permission for the app
    private void checkPermissionAndMakeCall(String number) {
        //If there is not a given call permission
        if (ActivityCompat.checkSelfPermission(this, CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{CALL_PHONE}, CALL_PERMISSION_CODE);
            Toast.makeText(getApplicationContext(), "Please allow call permission for this app!", Toast.LENGTH_SHORT).show();
        }
        //If there is a given call permission
        else {
            makeCall(number);
        }
    }

    //Method for what to do when the user accepts or declines the call permission for the app
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        //What to do when user accepts the call permission for the app
        if (requestCode == CALL_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                //What to do when user doesn't accepts the call permission for the app
                makeCall(number_for_call);
            }
        }
    }

    //Method for converting from hexadecimal value to an "UTF-8" String
    private String convertFromHexToUTF8(String input){
        //Declare and initialize a new "ByteBuffer" variable with the allocated value from the inputted String length divided by two
        ByteBuffer buff = ByteBuffer.allocate(input.length()/2);
        //Start a "for" cycle on every two characters of the inputted String
        for (int i = 0; i < input.length(); i+=2) {
            //Put every two bytes in the declared above buffer, from the inputted String, transformed in bytes for every two characters
            buff.put((byte)Integer.parseInt(input.substring(i, i+2), 16));
        }
        //Rewind the declared above buffer
        buff.rewind();
        //Declare and initialize a "Charset" variable to be equal to the standard "UTF-8" charset
        Charset cs = StandardCharsets.UTF_8;
        //Decode the above buffer's bytes to the standard "UTF-8" charset
        CharBuffer cb = cs.decode(buff);
        //Return the String value of the decoded buffer, for the current method
        return String.valueOf(cb);
    }

    //Method to choose a "vcf" file (used when the user clicks on the "import_contacts" item, from the "when_multi_choice_listener_is_inactive.xml" menu)
    public void chooseVCFFile(){
        //Declare and initialize a new "Intent" variable with action: "ACTION_OPEN_DOCUMENT"
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        //Add category for the new "Intent" variable to be: "CATEGORY_OPENABLE"
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        //Set the type for the "Intent" variable to be: "text/x-vcard"
        intent.setType("text/x-vcard");
        //Launch the "Intent" variable
        vcf_file_choose.launch(intent);
    }

    //Declare and initialize new "ActivityResultLauncher<Intent>" to get the result from the "Intent" variable used in the "chooseVCFFile()" method
    ActivityResultLauncher<Intent> vcf_file_choose = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
        @Override
        public void onActivityResult(ActivityResult result) {
            //What to do when the result code of the "Intent" variable, from the "chooseVCFFile()" method, is equal to "RESULT_OK" (it is the default state)
            if (result.getResultCode() == RESULT_OK) {
                //Declare and initialize a new "Intent" variable to be equal to the data passed from the "Inent" variable from the "chooseVCFFile()" method
                Intent data = result.getData();
                //What to do if the data passed from the "Inent" variable from the "chooseVCFFile()" method, is not equal to "null"
                if(data != null){
                    //Declare and initialize a new "StringBuilder" variable (used for storing the lines from the chosen file)
                    StringBuilder string_builder = new StringBuilder();
                    //Declare and initialize a new "Uri" variable to receive the data uri (the path to chosen file) of the "Inent" variable, from the "chooseVCFFile()" method
                    Uri uri = data.getData();
                    //Declare and initially initialize an "InputStream" variable with "null" value
                    InputStream inputStream = null;
                    //Begin "try-catch-finally" statement to read from the chosen file
                    try {
                        //Assert the declared above "Uri" variable to not not hold a null value
                        assert uri != null;
                        //Initialize the declared above "InputStream" variable to get the value from the file specified in the "Uri" variable (the path to chosen file)
                        inputStream = getContentResolver().openInputStream(uri);
                        //Declare and initialize a new "BufferedReader" variable with a reader source the "InputStream" variable
                        BufferedReader buffered_reader = new BufferedReader(new InputStreamReader(inputStream));
                        //Declare and initialize a String variable to read line by line the text from the chosen file by the user
                        String line = buffered_reader.readLine();
                        //Begin a "while" cycle to read the lines of the chosen file (while there are lines in the chosen file)
                        while (line != null) {
                            //Store all the lines in the declared above "StringBuilder" variable
                            string_builder.append(line).append("\n");
                            //Call the "readLine()" method on the "BufferedReader" variable to read the lines of the file (end the reading process in the "while" cycle)
                            line = buffered_reader.readLine();
                        }
                    }
                    //Throw an exception if there are unplanned scenarios
                    catch (Exception e) {
                        throw new RuntimeException(e);
                    }
                    //Begin the "finally" statement (when the "try-catch" statements finished)
                    finally {
                        //Declare and initialize a new "String[]" variable to split the "StringBuilder" variable on every occurrence of the word: "BEGIN"
                        String[] split_vcard = string_builder.toString().split("BEGIN", -1);
                        /*
                        Begin a "for" cycle to iterate through every "String[]" variable
                        (every split of the "StringBuilder" variable, starting from the first not the zero element)
                         */
                        for(int i = 1; i < split_vcard.length; i++){
                            /*
                            What to do if the "String[]" element contains a character "N;", in other words the name is in characters different from the "US-ASCII" charset,
                            which is the default charset for vCard version 2.1
                             */
                            if(split_vcard[i].contains("N;")){
                                //Declare and initialize a String variable to contain a substring value of the "String[]" element from the character "N;" to "FN;"
                                String name = split_vcard[i].substring(split_vcard[i].indexOf("N;"), split_vcard[i].indexOf("FN;"));
                                //Declare and initialize a String variable to contain a substring value of the declared above substring, starting from the character ":"
                                String name_from_dots = name.substring(name.indexOf(":") + 1);
                                /*
                                Declare and initialize a new "String[]" variable to split the above substring, starting from the character ":",
                                 on every occurence of the character ";"
                                 */
                                String[] split_name = name_from_dots.split(";");
                                //Declare and initialize a new String variable to contain a substring of the "String[]" element from the character "TEL;CELL:" to "END"
                                String phone = split_vcard[i].substring(split_vcard[i].indexOf("TEL;CELL:"), split_vcard[i].indexOf("END"));
                                //Declare and initialize a String variable to contain a substring value of the declared above substring, starting from the character ":"
                                String phone_from_dots = phone.substring(phone.indexOf(":") + 1);
                                /*
                                Declare and initialize a String variable to contain all the name fields from the certain "vCard" contact, converted from hexadecimal value
                                 to their respective "UTF-8" format, using the created above "convertFromHexToUTF8()" method. Replace every occurance of the character "="
                                 and new line ("\n") with "", in other words remove them. Between the name fields insert a space, represented by the " " element
                                 */
                                String full_name_vcard = convertFromHexToUTF8(split_name[3].replace("\n","").replace("=","")) + " " +
                                        convertFromHexToUTF8(split_name[1].replace("\n","").replace("=","")) + " " +
                                        convertFromHexToUTF8(split_name[2].replace("\n","").replace("=","")) + " " +
                                        convertFromHexToUTF8(split_name[0].replace("\n","").replace("=","")) + " " +
                                        convertFromHexToUTF8(split_name[4].replace("\n","").replace("=",""));
                                /*
                                Call the "insertDataThroughImport()" method from the "DatabaseHelper" class, and insert the values from the declared above String variables,
                                respectively for "full_name_vcard" and "phone_from_dots". For phone replace every occurance of the character "\n" (new line) with "".
                                In other words remove it
                                 */
                                myDb.insertDataThroughImport(full_name_vcard, phone_from_dots.replace("\n",""));
                            }
                            /*
                            What to do if the "String[]" element contains a character "N:", in other words the name is in characters supported by the "US-ASCII" charset,
                            which is the default charset for vCard version 2.1
                             */
                            else if(split_vcard[i].contains("N:")){
                                //Declare and initialize a String variable to contain a substring value of the "String[]" element from the character "\nN:" to "FN:"
                                String name = split_vcard[i].substring(split_vcard[i].indexOf("\nN:"), split_vcard[i].indexOf("FN:"));
                                //Declare and initialize a String variable to contain a substring value of the declared above substring, starting from the character ":"
                                String name_from_dots = name.substring(name.indexOf(":") + 1);
                                //Declare and initialize a new "String[]" variable to split the above substring, on every occurence of the character ";"
                                String[] split_name = name_from_dots.split(";");
                                //Declare and initialize a new String variable to contain a substring of the "String[]" element from the character "TEL;CELL:" to "END"
                                String phone = split_vcard[i].substring(split_vcard[i].indexOf("TEL;CELL:"),split_vcard[i].indexOf("END"));
                                //Declare and initialize a String variable to contain a substring value of the declared above substring, starting from the character ":"
                                String phone_from_dots = phone.substring(phone.indexOf(":") + 1);
                                /*
                                Declare and initialize a String variable to contain all the name fields from the certain "vCard" contact.
                                Between the name fields insert a space, represented by the " " element
                                 */
                                String full_name_vcard = split_name[3] + " " + split_name[1] + " " + split_name[2] + " " + split_name[0] + " " + split_name[4];
                                /*
                                Call the "insertDataThroughImport()" method from the "DatabaseHelper" class, and insert the values from the declared above String variables,
                                respectively for "full_name_vcard" and "phone_from_dots". Replace every occurance of the character "\n" (new line) with "".In other words remove it
                                 */
                                myDb.insertDataThroughImport(full_name_vcard.replace("\n",""), phone_from_dots.replace("\n",""));
                            }
                        }
                        //Call the build in "finish()" method after the importing process
                        finish();
                        //Declare and initialize a new "Intent" variable to be the "Contacts_Details_Activity", in other words refresh the activity
                        Intent intent = new Intent(Contacts_Details_Activity.this, Contacts_Details_Activity.class);
                        //Start the activity (refresh activity)
                        startActivity(intent);
                        //Show a message for the successful importing of the records
                        Toast.makeText(Contacts_Details_Activity.this, "Records imported successfully.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }
    });

    //Getter method for the "search_text_string" which will be used to pass the value from the search box in "Contacts_Details_Activity" class into the "DataAdapter" class
    public String getSearchTextString() {
        return search_text_string;
    }

    //Create the onCreate method (on "Contacts_Details" class startup)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacts_details);
        //Initialize the types (which we already declared) that are needed on startup
        return_menu_button = findViewById(R.id.return_button);
        info_button = findViewById(R.id.info_button);
        total_count_layout = findViewById(R.id.total_count_layout);
        total_count = findViewById(R.id.textview_total_count);
        search_text = findViewById(R.id.edittext_search);
        search_contact_layout = findViewById(R.id.search_text_layout);
        contact_list_list_view = findViewById(R.id.contact_list);
        toolbar = findViewById(R.id.toolbar);
        text_layout_search = findViewById(R.id.text_layout_search);
        //Initialize the "search_text_string" to receive the value from the "edittext_search" for the initial load of this activity
        search_text_string = search_text.getText().toString();
        //Add the toolbar for the Contacts_Details activity, from which the user can access the search, import and export functionalities
        setSupportActionBar(toolbar);
        //Connect the multi choice mode listener with the listview, in other words, whey you long click on the listview activate the multi choice mode is active
        contact_list_list_view.setMultiChoiceModeListener(modeListener);
        //Set the choice mode for the listview to be multiple in a modal view, in other words, when you are in a mode when the multi choice mode is active
        contact_list_list_view.setChoiceMode(AbsListView.CHOICE_MODE_MULTIPLE_MODAL);
        builder_for_options = new AlertDialog.Builder(this);
        builder_for_choice = new AlertDialog.Builder(this);
        myDb = new DatabaseHelper(this);
        dataList = new ArrayList<>();
        userList = new ArrayList<>();
        //Call the needed methods on startup
        loadListViewItems_wih_getAllData();
        viewRules();

        //On item click method for the listview
        contact_list_list_view.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                //Call the "closeKeyboard()" method to close the virtual keyboard on user's phone
                closeKeyboard();
                //Declare the strings for the dialog which we will create below
                String name, phone;
                //Get the position of the clicked item
                Item_Database contact = dataList.get(position);
                //Get the name and the phone of the clicked row
                name = contact.getName();
                phone = contact.getPhone();
                //Clear the focus from "search_text"
                search_text.clearFocus();
                //Clear the helper text of the "text_layout_search"
                text_layout_search.setHelperText("");
                //Initialize the "number_for_call" to be the phone number of the record that the user selected
                number_for_call = phone;
                //Create the alert dialog for to show the data of the clicked row
                builder_for_options.setTitle(name);
                builder_for_options.setMessage(phone);
                //Copy the contact name by clicking on the button
                builder_for_options.setPositiveButton("Copy contact name", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //Store the name of the contact temporarily in the clipboard
                        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        ClipData clip = ClipData.newPlainText("text", name);
                        clipboard.setPrimaryClip(clip);
                        Toast.makeText(getApplicationContext(), "Contact name copied.", Toast.LENGTH_SHORT).show();
                    }
                });
                //Copy the contact phone by clicking on the button
                builder_for_options.setNegativeButton("Copy contact phone", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //Store the phone of the contact temporarily in the clipboard
                        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        ClipData clip = ClipData.newPlainText("text", phone);
                        clipboard.setPrimaryClip(clip);
                        Toast.makeText(getApplicationContext(), "Contact phone copied.", Toast.LENGTH_SHORT).show();
                    }
                });
                //Call the selected number or not via the native phone calling app after "Call" button is clicked
                builder_for_options.setNeutralButton("Call", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //Confirm before we call
                        builder_for_choice.setTitle("Caution");
                        builder_for_choice.setMessage("Are you sure you wanna call " + phone + "?");
                        builder_for_choice.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            //Call the selected phone number via the native caller app
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                checkPermissionAndMakeCall(phone);
                            }
                        });
                        builder_for_choice.setNegativeButton("No", new DialogInterface.OnClickListener() {
                            //Set what to do if the user cancels his choice
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //Nothing to do here :-D
                            }
                        });
                        //Show the alert dialog via its built in method - "show()"
                        builder_for_choice.show();
                    }
                });
                //Create the dialog for the "Copy contact name; Copy contact phone; Call" methods and make the "Call" button in a certain color
                AlertDialog dialog = builder_for_options.create();
                dialog.setOnShowListener(new DialogInterface.OnShowListener() {
                    public void onShow(DialogInterface abc) {
                        //Change the text color in the end of the code if you want to be something different (Default: black)
                        dialog.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEUTRAL).setTextColor(getResources().getColor(android.R.color.black));
                        //Change the background color in the end of the code if you want to be something different (Default: holo_red_light)
                        dialog.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEUTRAL).setBackgroundColor(getResources().getColor(android.R.color.holo_red_light));
                    }
                });
                //Show the alert dialog via its built in method - "show()"
                dialog.show();
            }
        });

        //Create the method when you click on the return_button
        return_menu_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //If "UsedActionMode" is "true", in other words, the action mode has been used
                if (UsedActionMode) {
                    //Initialize the intent to be the "MainActivity" class (the main menu of the app)
                    Intent intent = new Intent(Contacts_Details_Activity.this, MainActivity.class);
                    //Remove activities from the history stack (don't return to the previous activity when the user clicks on the back button on his device)
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    //Start the activity - go to the "MainActivity" class (the main menu of the app)
                    startActivity(intent);
                }
                //If "UsedActionMode" is "false", in other words, the action mode has not been used
                else {
                    //Finish the activity on which you were before clicking on the button
                    finish();
                }
            }
        });

        /*
        Declare and initialize a new "TextWatcher" and its method, to show the searched matches in the "contact_list_list_view", depending on the data
        that user types in the "search_text" text box
        */
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            //What to do when user changes text in the "textWatcher"
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                //Initialize the "search_text_string" to receive the value from the "edittext_search" when user types in the search bar
                search_text_string = search_text.getText().toString();
                //Call the "loadListViewItems_with_getContactsByAKeyWord" method
                loadListViewItems_with_getContactsByAKeyWord();
                //What to do if there is no typed text in the "search_text" tex box, after the initial typed keyword from the user
                if (search_text.getText().toString().isEmpty()) {
                    //Set the color of the helper text of the "text_layout_search" to reg
                    text_layout_search.setHelperTextColor(ColorStateList.valueOf(getResources().getColor(R.color.red)));
                    //Set the helper text of the "text_layout_search"
                    text_layout_search.setHelperText("Type to search!");
                    //Call the "loadListViewItems_wih_getAllData" method
                    loadListViewItems_wih_getAllData();
                }
                //What to do if "datalist" is emptry, in other words there are no matches with the provided keyword
                else if (dataList.isEmpty()) {
                    //Set the color of the helper text of the "text_layout_search" to reg
                    text_layout_search.setHelperTextColor(ColorStateList.valueOf(getResources().getColor(R.color.red)));
                    //Set the helper text of the "text_layout_search"
                    text_layout_search.setHelperText("There are no matches in contact list!");
                }
                //What to do if "datalist" is not emptry, in other words there are matches with the provided keyword
                else {
                    //Set the color of the helper text of the "text_layout_search" to green
                    text_layout_search.setHelperTextColor(ColorStateList.valueOf(getResources().getColor(R.color.green)));
                    //What to do if there is only one record that matches the given keyword
                    if (dataList.size() == 1) {
                        //Set the helper text of the "text_layout_search" to show only one entry
                        text_layout_search.setHelperText("There is " + dataList.size() + " match in the contact list!");
                    } else {
                        //Set the helper text of the "text_layout_search" to show the total number of entries in the contact list that match the given keyword
                        text_layout_search.setHelperText("There are " + dataList.size() + " matches in the contact list!");
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        };
        //Add the newly created "textWatcher" to the "addTextChangedListener()" method of the "search_text" text box
        search_text.addTextChangedListener(textWatcher);
    }

    //Create the "onCreateOptionsMenu" method which will populate the menu items from "when_multi_choice_listener_is_inactive.xml", to the toolbar in the "Contact_Details" activity
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.when_multi_choice_listener_is_inactive, menu);
        return true;
    }

    //Method when "myMenu_multi_choice_inactive" is opened
    @Override
    public boolean onMenuOpened(int featureId, Menu menu) {
        //If the "search_contact_layout" visibility is set to "VISIBLE", change the title of the "search_contact" item in the menu
        if (search_contact_layout.getVisibility() == View.VISIBLE) {
            menu.findItem(R.id.search_contact).setTitle("Hide the search bar");
        }
        //If the "search_contact_layout" visibility is different from "VISIBLE", change the title of the "search_contact" item in the menu
        else {
            menu.findItem(R.id.search_contact).setTitle("Search for contacts");
        }
        return super.onMenuOpened(featureId, menu);
    }

    //Method for handling the the scenarios when an item from the menu is clicked
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //When clicked on the "search_contact" item
        if (item.getItemId() == R.id.search_contact) {
            //If the visibility of "search_contact_layout" is set to "VISIBLE", set it to "GONE", and vice versa
            if (search_contact_layout.getVisibility() == View.VISIBLE) {
                search_contact_layout.setVisibility(View.GONE);
            } else {
                search_contact_layout.setVisibility(View.VISIBLE);
            }
        }
        //When clicked on the "import_contacts" item
        if (item.getItemId() == R.id.import_contacts){
            chooseVCFFile();
        }
        //When clicked on the "export_contacts" item
        if (item.getItemId() == R.id.export_contacts) {
            //Declare and initialize String "file_path", to receive the value of the download directory path on the user's phone
            String file_path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).getPath();
            //Initialy declare and initialize a "FileWriter" variable to use in a "try-catch" statement. Give it a null value initialy
            FileWriter writer = null;
            //Begin "try-catch" statement with the "FileWriter" variable, because writing files to the internal storage demands it
            try {
                /*
                Set the "FileWriter" variable to take the value of the ".vcf" file that will be created in the "Downloads" directory
                on the user's phone. It will be caled "Phone records.vcf"
                 */
                writer = new FileWriter(file_path + "/Phone records.vcf");

            }
            //Catch if certain exceptions occur
            catch (Exception e) {
                throw new RuntimeException(e);
            }
            //Begin "for cycle" to insert every record from the database with contacts, to the "Phone records.vcf" file
            for(int i=0; i<dataList.size(); i++){
                try {
                    //Declare and initialize an "Item_Database" variable, to receive the value for each different contact
                    Item_Database contact_row = dataList.get(i);
                    //Begin with the insertion of every contact in the "Phone records.vcf" file
                    writer.write("BEGIN:VCARD\r\n");
                    writer.write("VERSION:3.0\r\n");
                    writer.write("N:;" + contact_row.getName() + ";;;\r\n");
                    writer.write("FN:" + contact_row.getName() + "\r\n");
                    writer.write("TEL;CELL:" + contact_row.getPhone() + "\r\n");
                    //Added a logger info for debugging (it is optional)
                    Log.d("contact name", contact_row.getName());
                    writer.write("END:VCARD\r\n");
                    //After the insertion of the last record from the database, call the "close()" method on the "FileWriter" variable
                    if(dataList.size()-1 == i)
                    {
                        writer.close();

                    }
                }
                //Catch if certain exceptions occur
                catch (Exception e) {
                    throw new RuntimeException(e);
                }
            }
            //Show a message that the creation of the file "Phone records.vcf", with all the records, is successfull
            Toast.makeText(getApplicationContext(), "Records exported to \"Phone records.vcf\", in \"Downloads\" directory!", Toast.LENGTH_LONG).show();
        }
        return true;
        }

    //Create the method for loading the data into listview (with "getAllData" method from the "DatabaseHelper" class)
    private void loadListViewItems_wih_getAllData() {
        //Initialize "dataList" to receive the result from the "getAllData" method in the "DatabaseHelper" class
        dataList = myDb.getAllData();
        //Initialize the "dataAdapter" to receive the value from "datalist", in other words get all rows from the database with user's contacts
        dataAdapter = new DataAdapter(this, dataList);
        //Set "dataAdapter" to load data into "contact_list_list_view"
        contact_list_list_view.setAdapter(dataAdapter);
        //Refresh "contact_list_list_view", in other words load the new data
        dataAdapter.notifyDataSetChanged();
    }

    //Create the method for loading the data into listview (with "getContactsByAKeyWord" method from the "DatabaseHelper" class)
    private void loadListViewItems_with_getContactsByAKeyWord() {
        //Initialize "dataList" to receive the result from the "getContactsByAKeyWord" method in the "DatabaseHelper" class
        dataList = myDb.getContactsByAKeyWord(search_text.getText().toString());
        //Initialize the "dataAdapter" to receive the value from "datalist", in other words all rows that match the typed keyword from the user, in the "search_text" text box
        dataAdapter = new DataAdapter(this, dataList);
        //Set "dataAdapter" to load data into "contact_list_list_view"
        contact_list_list_view.setAdapter(dataAdapter);
        //Refresh "contact_list_list_view", in other words load the new data
        dataAdapter.notifyDataSetChanged();
    }

    //Initialize the multi choice mode listener and create its methods
    AbsListView.MultiChoiceModeListener modeListener = new AbsListView.MultiChoiceModeListener() {

        //Method what to do when click on an item when multi choice mode listener is active
        @Override
        public void onItemCheckedStateChanged(ActionMode actionMode, int position, long l, boolean b) {
            //Initialize the "edit_button" MenuItem to be the edit_button item in the ActionMenu
            MenuItem edit_button = myMenu_multi_choice_active.findItem(R.id.edit_button);
            //Get the position of the clicked item
            Item_Database contact = dataList.get(position);
            //Set the checkbox to "checked" and vice versa on click
            contact.setChecked(!contact.isChecked());
            //Display the checked items as a total count on the action mode title
            if (userList.contains(contact)) {
                //Remove the selected contact by the user, if it exists in the "userList" array
                userList.remove(contact);
                action_mode.setTitle(userList.size() + " contact selected...");
            }else {
                //Add the selected contact by the user, if it doesn't exist in the "userList" array
                userList.add(contact);
                action_mode.setTitle(userList.size() + " contact selected...");
                //Turn on the visibility of the "edit_button" MenuItem when the checked record is only 1
            }if(userList.size() == 1){
                //Turn on the visibility of the "edit_button" MenuItem
                edit_button.setVisible(true);
                //Get the first value of the "userList" array to be assigned to the "contact_checked" which is from type "Item_Database"
                Item_Database contact_checked = userList.get(0);
                //Initialize the "ID_for_record" to be the value of the "getId" method of the "contact_checked" which is from type "Item_Database"
                ID_for_record = contact_checked.getId();
            }
            if(userList.isEmpty()){
                action_mode.setTitle("");
            }if(userList.size() > 1) {
                action_mode.setTitle(userList.size() + " contacts selected...");
                //Set the visibility of the edit button to false if more than one item is selected
                edit_button.setVisible(false);
            }
            //Notify the data change when item is clicked
            dataAdapter.notifyDataSetChanged();
        }

        //Create the method when multi choice mode listener is activated
        @SuppressLint("SetTextI18n")
        @Override
        public boolean onCreateActionMode(ActionMode actionMode, Menu menu) {
            //Call the "closeKeyboard()" method to close the virtual keyboard on user's phone
            closeKeyboard();
            //Declare and initialize new "params" with type "LinearLayout.LayoutParams" to get the layout parameters of "info_button"
            LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) info_button.getLayoutParams();
            //Set the end margin of the "params" to 25 pixels
            params.setMarginEnd(25);
            //Set "params" to change the end margin of "info_button"
            info_button.setLayoutParams(params);
            //Show the "when_multi_choice_listener_is_active.xml" menu when multi choice mode listener is activated
            MenuInflater menuInflater = actionMode.getMenuInflater();
            menuInflater.inflate(R.menu.when_multi_choice_listener_is_active,menu);
            //Assign declared "myMenu" to be the same as our menu
            myMenu_multi_choice_active = menu;
            //Set the "IsActionMode" to true when multi choice mode listener is activated, which is used to display or not the checkboxes
            IsActionMode = true;
            //Set the "UsedActionMode" to true, so it could be used later in the "onBackPressed()" and "return_menu_button.setOnClickListener" method
            UsedActionMode = true;
            //Set whether to display or not the title when multi choice mode listener is activated, which displays the items that are checked in total
            action_mode = actionMode;
            //Hide the "return_menu" button when multi choice mode listener is activated
            return_menu_button.setVisibility(View.GONE);
            //Set the text of "total_count" to show the count of user's saved contacts
            total_count.setText("Total count of contacts in list: " + dataList.size());
            //What to do, if the search box is empty
            if(search_text.getText().toString().isEmpty()){
                //Set the "total_count_layout" visibility to "visible", which will show the total count of the contacts in the database
                total_count_layout.setVisibility(View.VISIBLE);
            }
            //Set the visibility of the "toolbar" to "GONE"
            toolbar.setVisibility(View.GONE);
            //Set the "search_contact_layout" visibility to "GONE"
            search_contact_layout.setVisibility(View.GONE);
            return true;
        }

        //Create the method for refreshing an action mode's action menu whenever it is invalidated. It is not needed for the app so return is set to false!
        @Override
        public boolean onPrepareActionMode(ActionMode actionMode, Menu menu) {
            return false;
        }

        //Create a method for executing whenever an action of the action menu is clicked
        @Override
        public boolean onActionItemClicked(ActionMode actionMode, MenuItem menuItem) {
            //Create an alert dialog for the user to confirm the selected contact(s) deletion
            if (menuItem.getItemId() == R.id.delete_button){
                builder_for_choice.setTitle("Caution");
                if(userList.size() > 1){
                    builder_for_choice.setMessage("Delete selected contacts?");
                } else if (userList.size() == 1) {
                    builder_for_choice.setMessage("Delete selected contact?");
                }
                builder_for_choice.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    //Delete the data from database when the user confirms his choice
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        for (Item_Database row : userList){
                            //Delete data from database based on the checked item's id which is taken from the "getId()" method from the "Item_Database" class
                            myDb.deleteData(row.getId());
                            //Delete the checked rows from the "dataList" array
                            dataList.remove(row);
                        }
                        //Show a message for the successfully deleted contact(s)
                        if(userList.size() > 1){
                            Toast.makeText(getApplicationContext(), "Contacts successfully deleted.", Toast.LENGTH_SHORT ).show();
                        } else if (userList.size() == 1) {
                            Toast.makeText(getApplicationContext(), "Contact successfully deleted.", Toast.LENGTH_SHORT ).show();
                        }
                        //Call the finish method on the action mode parameter
                        actionMode.finish();
                        //If the database is empty return to "MainActivity" class
                        if(myDb.getAllData().isEmpty()){
                            //Initialize the intent to be the "MainActivity" class (the main menu of the app)
                            Intent intent = new Intent(Contacts_Details_Activity.this, MainActivity.class);
                            //Remove activities from the history stack (don't return to the previous activity when the user clicks on the back button on his device)
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            //Start the activity - go to the "MainActivity" class (the main menu of the app)
                            startActivity(intent);
                        }
                    }
                });
                builder_for_choice.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    //Set what to do if the user cancels his choice
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //Nothing to do here :-D
                    }
                });
                //Show the alert dialog via its built in method - "show()"
                builder_for_choice.show();
                //Return "true" if the "delete_button" of the multi choice mode listener is clicked, which is an item in the "when_multi_choice_listener_is_active.xml" file
                return true;
            }
            //Start the "Edit_Contact_Activity" when the user selects the "edit_button" item from the action menu
            else if (menuItem.getItemId() == R.id.edit_button){
                //Initialize the intent to be the "Edit_Contact_Activity" class
                Intent intent = new Intent(Contacts_Details_Activity.this, Edit_Contact_Activity.class);
                //Remove activities from the history stack (don't return to the previous activity when the user clicks on the back button on his device)
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                //Start the activity - go to the "Edit_Contact_Activity" class
                startActivity(intent);
                //Return "true" if the "edit_button" of the multi choice mode listener is clicked, which is an item in the "when_multi_choice_listener_is_active.xml" file
                return true;
            }
            else {
                //Return "false" if the "delete_button" or the "edit_button" of the multi choice mode listener are not clicked, which are items in the "when_multi_choice_listener_is_active.xml" file
                return false;
            }
        }

        //Create the method when exiting (destroying) the multi choice mode listener
        @Override
        public void onDestroyActionMode(ActionMode actionMode) {
            //Declare and initialize new "params" with type "LinearLayout.LayoutParams" to get the layout parameters of "info_button"
            LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) info_button.getLayoutParams();
            //Set the end margin of the "params" to 0 pixels
            params.setMarginEnd(0);
            //Set "params" to change the end margin of "info_button"
            info_button.setLayoutParams(params);
            //Set the "IsActionMode" to "false" when the user exits the action mode, which is used to display or not the checkboxes
            IsActionMode = false;
            //Deselect every checked row when exiting the action mode
            for (Item_Database row : userList){
                row.setChecked(false);
            }
            //Set "action_mode" to "null" when the user exits the action mode, which is used to display the title of the action mode
            action_mode = null;
            //Clear the "userList" array from data, which is used to contain the data of the checked items
            userList.clear();
            //Show the "return_menu" button when the user exits the action mode
            return_menu_button.setVisibility(View.VISIBLE);
            //Set the "total_count_layout" visibility to "gone", which will hide the total count of the contacts in the database
            total_count_layout.setVisibility(View.GONE);
            //Set the visibility of the "toolbar" to "VISIBLE"
            toolbar.setVisibility(View.VISIBLE);
            //Set the "search_contact_layout" visibility to "GONE"
            search_contact_layout.setVisibility(View.GONE);
        }
    };

    //Create the method when the user clicks on the "info_button" to show him "Useful information"
    public void viewRules() {
        info_button.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(Contacts_Details_Activity.this);
                        builder.setTitle(Html.fromHtml("<h4><b>Useful information</b></h4>"));
                        builder.setMessage(Html.fromHtml("<p>• To view available commands for a record <u>click</u> on it.</p>" +
                                "<p>• To view the available features for a record, <u>click and hold</u> on it.</p>" +
                                "<p>• To search for a name or phone, click on the \"<u>Search for contacts</u>\" item in the menu.<br>" +
                                "You can search for a name or phone, simply type in the search box and every occurance will show, no matter if it's a name or phone.</p>" +
                                "<p>• To import contacts from an external \"<u>.vcf</u>\" file, click on the \"<u>Import contacts from a .vcf file</u>\" item in the menu.</p>" +
                                "<p>• To export the contact list to an external \"<u>.vcf</u>\" file, click on the \"<u>Export contacts to a .vcf file</u>\" item in the menu.</p>" +
                                "<p>• To edit a record <u>click and hold</u> on it, then click on the edit button <font color=\"#00BFFF\">(the blue pen)</font>.<br>" +
                                "For the edit feature to be available you must select one record only.</p>" +
                                "<p>• To delete a record <u>click and hold</u> on it, then select the delete button <font color=\"#FF0000\">(the red recycle bin)</font>.<br>" +
                                "You can delete multiple records at a time, just select them.</p>"));
                        builder.show();
                    }
                }
        );
    }

    //Method to handle the activity when the back button, on the user's device, is pressed
    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        //If "UsedActionMode" is "true", in other words, the action mode has been used
        if (UsedActionMode){
            //Initialize the intent to be the "MainActivity" class (the main menu of the app)
            Intent intent = new Intent(Contacts_Details_Activity.this, MainActivity.class);
            //Remove activities from the history stack (don't return to the previous activity when the user clicks on the back button on his device)
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            //Start the activity - go to the "MainActivity" class (the main menu of the app)
            startActivity(intent);
        }
        //If "UsedActionMode" is "false", in other words, the action mode has not been used
        else {
            //Finish the activity on which you were before clicking on the button
            finish();
        }
    }
}