package com.phonerecords.Adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.provider.ContactsContract;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.RequiresApi;

import com.phonerecords.Contacts_Details_Activity;
import com.phonerecords.DataModel.Item_Database;
import com.phonerecords.DatabaseHelper;
import com.phonerecords.R;

import java.lang.reflect.WildcardType;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DataAdapter extends BaseAdapter {
    //Declare the context and data list variables
    Context context;
    ArrayList<Item_Database> dataList;

    //Create the method for the listview data adapter
    public DataAdapter(Context context, ArrayList<Item_Database> dataList){
        this.context = context;
        this.dataList = dataList;
    }

    //Get listview item id
    @Override
    public long getItemId(int position) {
        return position;
    }

    //Get listview item
    @Override
    public Object getItem(int position) {
        return dataList.get(position);
    }

    //Get the view of the items in the rows of the listview
    @SuppressLint("ViewHolder")
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //Inflate the view with the "listview_item.xml" layout and initialize its items in the listview
        LayoutInflater inflater = ((Contacts_Details_Activity)context).getLayoutInflater();
        View row = inflater.inflate(R.layout.listview_item,parent,false);
        TextView text_name = row.findViewById(R.id.contact_name);
        TextView text_phone = row.findViewById(R.id.contact_phone);
        CheckBox checkBox = row.findViewById(R.id.checkBox);
        //Get the position corresponding to the selected item in the listview
        Item_Database contact = dataList.get(position);
        //Initialize a new instance of the "Contacts_Details_Activity" class, to access the "search_text_string" from it
        Contacts_Details_Activity contacts_details = new Contacts_Details_Activity();
        //Declare and initialize new String "search_text_string" to receive the value of "search_text_string" from the "Contacts_Details_Activity" class
        String search_text_string = contacts_details.getSearchTextString();
        //What to do if the newly initialized "search_text_string" (the search box in the "Contacts_Details_Activity" class), is empty
        if(search_text_string.isEmpty()){
            //Set the values of the items from the getter methods of the "Item_Database" class
            text_name.setText(contact.getName());
            text_phone.setText(contact.getPhone());
            checkBox.setChecked(contact.isChecked());
        }
        //What to do if the newly initialized "search_text_string" (the search box in the "Contacts_Details_Activity" class), is not empty
        else {
            //Declare a new "Pattern" variable
            Pattern new_pattern;
            /*
            Initialize "new_pattern" with the "compile()" method, to receive the value from the search box in the "Contacts_Details_Activity" class.
            It is done by this way with flag: "Pattern.CASE_INSENSITIVE", so when the user types in the search box all matches from the list view come up,
            no matter the case sensitivity of the letter. The flag: "Pattern.LITERAL" means if an regex symbol is used it is rendered as the exact symbol and not regex expression.
             */
            new_pattern = Pattern.compile(search_text_string, Pattern.CASE_INSENSITIVE|Pattern.LITERAL);
            //Declare and initialy initialize String variables which will be used in "if" statements
            String modified_text_for_name = "";
            String modified_text_for_phone = "";
            /*
            Declare and initialize new "Matcher" variables and put the previously created "new_pattern" in its "matcher()" method to match characters from the
            "getName()" and "getPhone()" methods, in the "Item_Database" class
            */
            Matcher matcher_contact_name = new_pattern.matcher(contact.getName());
            Matcher matcher_contact_phone = new_pattern.matcher(contact.getPhone());
            //What to do if the first character that user entered in the search box is not a letter or a digit (used for cases when user enters a symbol to search for)
            if(!Character.isLetterOrDigit(search_text_string.charAt(0))){
                //What to do when there are matches for the name with the searched word from the user
                if (matcher_contact_name.find()){
                /*
                Declare and initialize String "replace_text_with_for_name", to receice the following "html" code with the matched values from "getName()" method,
                which are represented in the "group()" method of "matcher"
                */
                    String replace_text_with_for_name = "<span style='background-color:yellow'>" + matcher_contact_name.group() + "</span>";
                /*
                Initialize String "modified_text_for_name", to receive the value from the "replaceFirst()" method, where "matcher_contact_name.group()" will be
                replaiced with "replace_text_with_for_name", on the first occurance only.
                */
                    modified_text_for_name = contact.getName().replaceFirst("\\" + matcher_contact_name.group(), replace_text_with_for_name);
                //Initialize "modified_text_for_phone", to receive the value from the "getPhone()" method for the certain contact
                    modified_text_for_phone = contact.getPhone();
                }
                //What to do when there are matches for the phone with the searched word from the user
                if (matcher_contact_phone.find()){
                /*
                Declare and initialize String "replace_text_with_for_phone", to receice the following "html" code with the matched values from "getPhone()" method,
                which are represented in the "group()" method of "matcher"
                */
                    String replace_text_with_for_phone = "<span style='background-color:yellow'>" + matcher_contact_phone.group() + "</span>";
                //Initialize "modified_text_for_name", to receive the value from the "getName()" method for the certain contact
                    modified_text_for_name = contact.getName();
                /*
                Initialize String "modified_text_for_phone", to receive the value from the "replaceFirst()" method, where "matcher_contact_phone.group()" will be
                replaiced with "replace_text_with_for_phone", on the first occurance only.
                */
                    modified_text_for_phone = contact.getPhone().replaceFirst("\\" + matcher_contact_phone.group(), replace_text_with_for_phone);
                }
            }
            //What to do if the first character that user entered in the search box is a letter or a digit
            else
            {
                //What to do when there are matches for the name with the searched word from the user
                if (matcher_contact_name.find()){
                /*
                Declare and initialize String "replace_text_with_for_name", to receice the following "html" code with the matched values from "getName()" method,
                which are represented in the "group()" method of "matcher"
                */
                    String replace_text_with_for_name = "<span style='background-color:yellow'>" + matcher_contact_name.group() + "</span>";
                /*
                Initialize String "modified_text_for_name", to receive the value from the "replaceFirst()" method, where "matcher_contact_name.group()" will be
                replaiced with "replace_text_with_for_name", on the first occurance only.
                */
                    modified_text_for_name = contact.getName().replaceFirst(matcher_contact_name.group(), replace_text_with_for_name);
                //Initialize "modified_text_for_phone", to receive the value from the "getPhone()" method for the certain contact
                    modified_text_for_phone = contact.getPhone();
                }
                //What to do when there are matches for the phone with the searched word from the user
                if (matcher_contact_phone.find()){
                /*
                Declare and initialize String "replace_text_with_for_phone", to receice the following "html" code with the matched values from "getPhone()" method,
                which are represented in the "group()" method of "matcher"
                */
                    String replace_text_with_for_phone = "<span style='background-color:yellow'>" + matcher_contact_phone.group() + "</span>";
                //Initialize "modified_text_for_name", to receive the value from the "getName()" method for the certain contact
                    modified_text_for_name = contact.getName();
                /*
                Initialize String "modified_text_for_phone", to receive the value from the "replaceFirst()" method, where "matcher_contact_phone.group()" will be
                replaiced with "replace_text_with_for_phone", on the first occurance only.
                */
                    modified_text_for_phone = contact.getPhone().replaceFirst(matcher_contact_phone.group(), replace_text_with_for_phone);
                }
            }
            //Set the text in the "text_name" and "text_phone" to be respectively: "modified_text_for_name" and "modified_text_for_phone"
            text_name.setText(Html.fromHtml(modified_text_for_name));
            text_phone.setText(Html.fromHtml(modified_text_for_phone));
            //Set the value of the "checkBox" item to "isChecked()" from the getter methods of the "Item_Database" class
            checkBox.setChecked(contact.isChecked());
        }
        //Show,hide checkbox on startup of the mode listener in the "Contact_Details" class
        if(Contacts_Details_Activity.IsActionMode){
            checkBox.setVisibility(View.VISIBLE);
        }
        else {
            checkBox.setVisibility(View.GONE);
        }
        return row;
    }

    //Get listview count
    @Override
    public int getCount() {
        return this.dataList.size();
    }

}
