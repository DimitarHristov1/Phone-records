package com.phonerecords;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.view.View;
import android.widget.Toast;

import com.phonerecords.DataModel.Item_Database;

import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {
    //Declare the variables that are needed and initialize them
    public static final String DATABASE_NAME = "Contacts.db";
    public static final String TABLE_NAME = "contact_table";
    public static final String COLUMN_ID = "ID";
    public static final String COLUMN_ONE = "NAME";
    public static final String COLUMN_TWO = "PHONE";
    public static final String COLUMN_THREE = "[ADDITIONAL INFORMATION]";

    //Create the method for the "DatabaseHelper", with which we can declare variables from type "DatabaseHelper" to access the methods from this class
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 2);
    }

    //Create the method for the database creation
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_NAME + "(" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_ONE + " TEXT, " + COLUMN_TWO + " TEXT, " + COLUMN_THREE + " TEXT)");
    }

    //Execute the code in this method, if the existing database version is older, that the version used in the "DatabaseHelper" method
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("ALTER TABLE " + TABLE_NAME + " ADD COLUMN " + COLUMN_THREE + " TEXT DEFAULT \"\"");
    }

    //Execute the code in this method, if the existing database version is newer, that the version used in the "DatabaseHelper" method
    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onCreate(db);
    }

    //Create the method for inserting data into the table
    public boolean insertData(String name,String phone, String additional_information) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_ONE,name);
        contentValues.put(COLUMN_TWO,phone);
        contentValues.put(COLUMN_THREE,additional_information);
        long result = db.insert(TABLE_NAME,null ,contentValues);
        return result != -1;
    }

    //Create a method for updating a record, used within the "Edit.Contact.Activity" class
    public boolean updateRecord(int contact_id, String name, String phone, String additional_information){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues update_values = new ContentValues();
        update_values.put(COLUMN_ONE, name);
        update_values.put(COLUMN_TWO, phone);
        update_values.put(COLUMN_THREE, additional_information);
        long result = db.update(TABLE_NAME, update_values, "ID = ?", new String[]{String.valueOf(contact_id)});
        return result != -1;
    }

    //Create the method for deleting data from the table
    public void deleteData (int contact_id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, "ID = ?", new String[]{String.valueOf(contact_id)});
    }

    //Create the method with which we can show the data from the table
    public ArrayList<Item_Database> getAllData(){
        ArrayList<Item_Database> dataList = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        @SuppressLint("Recycle") Cursor cursor = db.rawQuery("SELECT * FROM "+ TABLE_NAME,null);
        //Move the cursor through the table rows, so we can store them temporarily in the "Item_Database" array
        while (cursor.moveToNext()){
            int id = cursor.getInt(0);
            String name = cursor.getString(1);
            String phone = cursor.getString(2);
            String additional_information = cursor.getString(3);
            Item_Database contact = new Item_Database(id, name, phone, additional_information, false);
            dataList.add(contact);
        }
        return dataList;
    }

    //Create a method for retrieving the name of a contact with specified ID, for the "Edit_Contact_Activity" class
    public String getNameContact (int contact_id) {
        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<Item_Database> dataList = new ArrayList<>();
        @SuppressLint("Recycle") Cursor cursor = db.rawQuery("SELECT * FROM "+ TABLE_NAME + " WHERE ID=" + contact_id,null);
        while (cursor.moveToNext()){
            int id = cursor.getInt(0);
            String name = cursor.getString(1);
            String phone = cursor.getString(2);
            String additional_information = cursor.getString(3);
            Item_Database contact = new Item_Database(id, name, phone, additional_information, false);
            dataList.add(contact);
        }
        return dataList.get(0).getName();
    }

    //Create a method for retrieving the phone of a contact with specified ID, for the "Edit_Contact_Activity" class
    public String getPhoneContact (int contact_id) {
        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<Item_Database> dataList = new ArrayList<>();
        @SuppressLint("Recycle") Cursor cursor = db.rawQuery("SELECT * FROM "+ TABLE_NAME + " WHERE ID=" + contact_id,null);
        while (cursor.moveToNext()){
            int id = cursor.getInt(0);
            String name = cursor.getString(1);
            String phone = cursor.getString(2);
            String additional_information = cursor.getString(3);
            Item_Database contact = new Item_Database(id, name, phone, additional_information, false);
            dataList.add(contact);
        }
        return dataList.get(0).getPhone();
    }

    //Create a method for retrieving the additional information of a contact with specified ID, for the "Edit_Contact_Activity" class
    public String getAdditionalInformationContact (int contact_id) {
        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<Item_Database> dataList = new ArrayList<>();
        @SuppressLint("Recycle") Cursor cursor = db.rawQuery("SELECT * FROM "+ TABLE_NAME + " WHERE ID=" + contact_id,null);
        while (cursor.moveToNext()){
            int id = cursor.getInt(0);
            String name = cursor.getString(1);
            String phone = cursor.getString(2);
            String additional_information = cursor.getString(3);
            Item_Database contact = new Item_Database(id, name, phone, additional_information, false);
            dataList.add(contact);
        }
        return dataList.get(0).getAdditional_information();
    }

    //Create a method for retrieving contacts by a keyword (no matter it is a name or phone number)
    public ArrayList<Item_Database> getContactsByAKeyWord (String keyword) {
        SQLiteDatabase db = this.getReadableDatabase();
        ArrayList<Item_Database> dataList = new ArrayList<>();
        @SuppressLint("Recycle") Cursor cursor = db.rawQuery("SELECT * FROM "+ TABLE_NAME + " WHERE NAME LIKE '%\\" + keyword + "%' ESCAPE '\\' OR PHONE LIKE '%\\" + keyword + "%' ESCAPE '\\'",null);
        while (cursor.moveToNext()){
            int id = cursor.getInt(0);
            String name = cursor.getString(1);
            String phone = cursor.getString(2);
            String additional_information = cursor.getString(3);
            Item_Database contact = new Item_Database(id, name, phone, additional_information, false);
            dataList.add(contact);
        }
        return dataList;
    }

    //Create the method for inserting data into database through import from a "vcf" file
    public void insertDataThroughImport (String name, String phone, String additional_information) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_ONE,name);
        contentValues.put(COLUMN_TWO,phone);
        contentValues.put(COLUMN_THREE,additional_information);
        db.insert(TABLE_NAME,null ,contentValues);
    }
}

