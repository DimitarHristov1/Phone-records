package com.phonerecords;

import static android.Manifest.permission.CALL_PHONE;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.phonerecords.Adapter.DataAdapter;
import com.phonerecords.DataModel.Item_Database;

import java.util.ArrayList;

public class Contacts_Details_Activity extends AppCompatActivity {
    //Declare the variables that are needed
    ListView contact_list_list_view;
    ImageButton return_menu_button, info_button;
    DatabaseHelper myDb;
    DataAdapter dataAdapter;
    //Declare "builder_for_options" with type "AlertDialog.Builder builder" for the options that user has when he clicks on a record
    AlertDialog.Builder builder_for_options;
    //Declare "builder_for_choice" for confirming the choice before calling
    AlertDialog.Builder builder_for_choice;
    //Declare "myMenu" of a type "Menu", so we can access the items from our menu
    private static Menu myMenu;
    private static ArrayList<Item_Database> dataList, userList;
    //Boolean value to check if action mode is activated
    public static boolean IsActionMode = false;
    //Boolean value to check if action mode was used
    public static boolean UsedActionMode = false;
    //"ActionMode" value used for changing the title of the action mode menu when it is activated
    private static ActionMode action_mode = null;
    private static final int CALL_PERMISSION_CODE = 100;
    //Declare the "number_for_call" with type "String" which we will use with the "onRequestPermissionsResult" method
    private static String number_for_call;
    //Declare the "ID_for_record" String which we will use in the "Edit_Contact_Activity" class
    public static int ID_for_record;

    //Method for making a call when user selects "Call" button from the alert dialog
    private void makeCall(String phoneNumber){
        Intent intent = new Intent(Intent.ACTION_CALL);
        intent.setData(Uri.parse("tel:" + phoneNumber));
        startActivity(intent);
    }

    //Method to check if there is a given call permission for the app
    private void checkPermissionAndMakeCall(String number){
        //If there is not a given call permission
        if (ActivityCompat.checkSelfPermission(this, CALL_PHONE) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[]{CALL_PHONE}, CALL_PERMISSION_CODE);
            Toast.makeText(getApplicationContext(), "Please allow call permission for this app!", Toast.LENGTH_SHORT).show();
        }
        //If there is a given call permission
        else {
            makeCall(number);
        }
    }

    //Method for what to do when the user accepts or declines the call permission for the app
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        //What to do when user accepts the call permission for the app
        if (requestCode == CALL_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                makeCall(number_for_call);
            //What to do when user doesn't accepts the call permission for the app
            } else {
                //Write some code here, if you want :)
            }
        }
    }

    //Create the onCreate method (on "Contacts_Details" class startup)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacts_details);
        //Initialize the types (which we already declared) that are needed on startup
        return_menu_button = findViewById(R.id.return_button);
        info_button = findViewById(R.id.info_button);
        contact_list_list_view = findViewById(R.id.contact_list);
        //Connect the multi choice mode listener with the listview, in other words, whey you long click on the listview activate the multi choice mode is active
        contact_list_list_view.setMultiChoiceModeListener(modeListener);
        //Set the choice mode for the listview to be multiple in a modal view, in other words, when you are in a mode when the multi choice mode is active
        contact_list_list_view.setChoiceMode(AbsListView.CHOICE_MODE_MULTIPLE_MODAL);
        builder_for_options = new AlertDialog.Builder(this);
        builder_for_choice = new AlertDialog.Builder(this);
        myDb = new DatabaseHelper(this);
        dataList = new ArrayList<>();
        userList = new ArrayList<>();
        //Call the needed methods on startup
        loadListViewItems();
        viewRules();

        //On item click method for the listview
        contact_list_list_view.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                //Declare the strings for the dialog which we will create below
                String name, phone;
                //Get the position of the clicked item
                Item_Database contact = dataList.get(position);
                //Get the name and the phone of the clicked row
                name = contact.getName();
                phone = contact.getPhone();
                //Initialize the "number_for_call" to be the phone number of the record that the user selected
                number_for_call = phone;
                //Create the alert dialog for to show the data of the clicked row
                //AlertDialog.Builder builder = new AlertDialog.Builder(new ContextThemeWrapper(Contacts_Details.this,R.style.MyDialog));
                builder_for_options.setTitle(name);
                builder_for_options.setMessage(phone);
                //Copy the contact name by clicking on the button
                builder_for_options.setPositiveButton("Copy contact name", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //Store the name of the contact temporarily in the clipboard
                        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        ClipData clip = ClipData.newPlainText("text",name);
                        clipboard.setPrimaryClip(clip);
                        Toast.makeText(getApplicationContext(), "Contact name copied.", Toast.LENGTH_SHORT ).show();
                    }
                });
                //Copy the contact phone by clicking on the button
                builder_for_options.setNegativeButton("Copy contact phone", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //Store the phone of the contact temporarily in the clipboard
                        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        ClipData clip = ClipData.newPlainText("text",phone);
                        clipboard.setPrimaryClip(clip);
                        Toast.makeText(getApplicationContext(), "Contact phone copied.", Toast.LENGTH_SHORT ).show();
                    }
                });
                //Call the selected number or not via the native phone calling app after "Call" button is clicked
                builder_for_options.setNeutralButton("Call", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //Confirm before we call
                        builder_for_choice.setTitle("Caution");
                        builder_for_choice.setMessage("Are you sure you wanna call " + phone + "?");
                        builder_for_choice.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            //Call the selected phone number via the native caller app
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                checkPermissionAndMakeCall(phone);
                            }
                        });
                        builder_for_choice.setNegativeButton("No", new DialogInterface.OnClickListener() {
                            //Set what to do if the user cancels his choice
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //Nothing to do here :-D
                            }
                        });
                        //Show the alert dialog via its built in method - "show()"
                        builder_for_choice.show();
                    }
                });
                //Create the dialog for the "Copy contact name; Copy contact phone; Call" methods and make the "Call" button in a certain color
                AlertDialog dialog = builder_for_options.create();
                dialog.setOnShowListener(new DialogInterface.OnShowListener() {
                    public void onShow(DialogInterface abc){
                        //Change the text color in the end of the code if you want to be something different (Default: black)
                        dialog.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEUTRAL).setTextColor(getResources().getColor(android.R.color.black));
                        //Change the background color in the end of the code if you want to be something different (Default: holo_red_light)
                        dialog.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEUTRAL).setBackgroundColor(getResources().getColor(android.R.color.holo_red_light));
                    }
                });
                //Show the alert dialog via its built in method - "show()"
                dialog.show();
            }
        });

        //Create the method when you click on the return_button
        return_menu_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //If "UsedActionMode" is "true", in other words, the action mode has been used
                if (UsedActionMode){
                    //Initialize the intent to be the "MainActivity" class (the main menu of the app)
                    Intent intent = new Intent(Contacts_Details_Activity.this, MainActivity.class);
                    //Remove activities from the history stack (don't return to the previous activity when the user clicks on the back button on his device)
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    //Start the activity - go to the "MainActivity" class (the main menu of the app)
                    startActivity(intent);
                }
                //If "UsedActionMode" is "false", in other words, the action mode has not been used
                else {
                    //Finish the activity on which you were before clicking on the button
                    finish();
                }
            }
        });
    }

    //Create the method for loading the data into listview
    private void loadListViewItems() {
        dataList = myDb.getAllData();
        dataAdapter = new DataAdapter(this, dataList);
        contact_list_list_view.setAdapter(dataAdapter);
        dataAdapter.notifyDataSetChanged();
    }

    //Initialize the multi choice mode listener and create its methods
    AbsListView.MultiChoiceModeListener modeListener = new AbsListView.MultiChoiceModeListener() {

        //Method what to do when click on an item when multi choice mode listener is active
        @Override
        public void onItemCheckedStateChanged(ActionMode actionMode, int position, long l, boolean b) {
            //Initialize the "edit_button" MenuItem to be the edit_button item in the ActionMenu
            MenuItem edit_button = myMenu.findItem(R.id.edit_button);
            //Get the position of the clicked item
            Item_Database contact = dataList.get(position);
            //Set the checkbox to "checked" and vice versa on click
            contact.setChecked(!contact.isChecked());
            //Display the checked items as a total count on the action mode title
            if (userList.contains(contact)) {
                userList.remove(contact);
                action_mode.setTitle(userList.size() + " contact selected...");
            }else {
                userList.add(contact);
                action_mode.setTitle(userList.size() + " contact selected...");
                //Turn on the visibility of the "edit_button" MenuItem when the checked record is only 1
            }if(userList.size() == 1){
                //Turn on the visibility of the "edit_button" MenuItem
                edit_button.setVisible(true);
                //Get the first value of the "userList" array to be assigned to the "contact_checked" which is from type "Item_Database"
                Item_Database contact_checked = userList.get(0);
                //Initialize the "ID_for_record" to be the value of the "getId" method of the "contact_checked" which is from type "Item_Database"
                ID_for_record = contact_checked.getId();
            }
            if(userList.isEmpty()){
                action_mode.setTitle("");
            }if(userList.size() > 1) {
                action_mode.setTitle(userList.size() + " contacts selected...");
                //Set the visibility of the edit button to false if more than one item is selected
                edit_button.setVisible(false);
            }
            //Notify the data change when item is clicked
            dataAdapter.notifyDataSetChanged();
        }
        //Create the method when multi choice mode listener is activated
        @Override
        public boolean onCreateActionMode(ActionMode actionMode, Menu menu) {
            //Show the "my_options_menu.xml" menu when multi choice mode listener is activated
            MenuInflater menuInflater = actionMode.getMenuInflater();
            menuInflater.inflate(R.menu.my_options_menu,menu);
            //Assign declared "myMenu" to be the same as our menu
            myMenu = menu;
            //Set the "IsActionMode" to true when multi choice mode listener is activated, which is used to display or not the checkboxes
            IsActionMode = true;
            //Set the "UsedActionMode" to true, so it could be used later in the "onBackPressed()" and "return_menu_button.setOnClickListener" method
            UsedActionMode = true;
            //Set whether to display or not the title when multi choice mode listener is activated, which displays the items that are checked in total
            action_mode = actionMode;
            //Hide the "return_menu" button when multi choice mode listener is activated
            return_menu_button.setVisibility(View.GONE);
            return true;
        }

        //Create the method for refreshing an action mode's action menu whenever it is invalidated. It is not needed for the app so return is set to false!
        @Override
        public boolean onPrepareActionMode(ActionMode actionMode, Menu menu) {
            return false;
        }

        //Create a method for executing whenever an action of the action menu is clicked
        @Override
        public boolean onActionItemClicked(ActionMode actionMode, MenuItem menuItem) {
            //Create an alert dialog for the user to confirm the selected contact(s) deletion
            if (menuItem.getItemId() == R.id.delete_button){
                builder_for_choice.setTitle("Caution");
                if(userList.size() > 1){
                    builder_for_choice.setMessage("Delete selected contacts?");
                } else if (userList.size() == 1) {
                    builder_for_choice.setMessage("Delete selected contact?");
                }
                builder_for_choice.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    //Delete the data from database when the user confirms his choice
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        for (Item_Database row : userList){
                            //Delete data from database based on the checked item's id which is taken from the "getId()" method from the "Item_Database" class
                            myDb.deleteData(row.getId());
                        }
                        //Show a message for the successfully deleted contact(s)
                        if(userList.size() > 1){
                            Toast.makeText(getApplicationContext(), "Contacts successfully deleted.", Toast.LENGTH_SHORT ).show();
                        } else if (userList.size() == 1) {
                            Toast.makeText(getApplicationContext(), "Contact successfully deleted.", Toast.LENGTH_SHORT ).show();
                        }
                        //Call the finish method on the action mode parameter
                        actionMode.finish();
                        //If the database is empty return to "MainActivity" class
                        if(myDb.getAllData().isEmpty()){
                            //Initialize the intent to be the "MainActivity" class (the main menu of the app)
                            Intent intent = new Intent(Contacts_Details_Activity.this, MainActivity.class);
                            //Remove activities from the history stack (don't return to the previous activity when the user clicks on the back button on his device)
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            //Start the activity - go to the "MainActivity" class (the main menu of the app)
                            startActivity(intent);
                        }
                    }
                });
                builder_for_choice.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    //Set what to do if the user cancels his choice
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //Nothing to do here :-D
                    }
                });
                //Show the alert dialog via its built in method - "show()"
                builder_for_choice.show();
                //Return "true" if the "delete_button" of the multi choice mode listener is clicked, which is an item in the "my_options_menu.xml" file
                return true;
            }
            //Start the "Edit_Contact_Activity" when the user selects the "edit_button" item from the action menu
            if (menuItem.getItemId() == R.id.edit_button){
                //Initialize the intent to be the "Edit_Contact_Activity" class
                Intent intent = new Intent(Contacts_Details_Activity.this, Edit_Contact_Activity.class);
                //Remove activities from the history stack (don't return to the previous activity when the user clicks on the back button on his device)
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                //Start the activity - go to the "Edit_Contact_Activity" class
                startActivity(intent);
                //Return "true" if the "edit_button" of the multi choice mode listener is clicked, which is an item in the "my_options_menu.xml" file
                return true;
            }
            else {
                //Return "false" if the "delete_button" or the "edit_button" of the multi choice mode listener are not clicked, which are items in the "my_options_menu.xml" file
                return false;
            }
        }

        //Create the method when exiting (destroying) the multi choice mode listener
        @Override
        public void onDestroyActionMode(ActionMode actionMode) {
            //Initialize the intent to be the "Contacts_Details_Activity" class, in other words refresh the activity
            Intent intent = new Intent(Contacts_Details_Activity.this, Contacts_Details_Activity.class);
            //Start the activity (refresh the activity)
            startActivity(intent);
            //Override the pending transition, in other words don't refresh the "Contacts_Details_Activity" 2 times when the user exits the action mode
            overridePendingTransition(0, 0);
            //Set the "IsActionMode" to "false" when the user exits the action mode, which is used to display or not the checkboxes
            IsActionMode = false;
            //Set "action_mode" to "null" when the user exits the action mode, which is used to display the title of the action mode
            action_mode = null;
            //Clear the "userList" array from data, which is used to contain the data of the checked items
            userList.clear();
            //Show the "return_menu" button when the user exits the action mode
            return_menu_button.setVisibility(View.VISIBLE);
        }
    };

    //Create the method when the user clicks on the "info_button" to show him "Useful information"
    public void viewRules() {
        info_button.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(Contacts_Details_Activity.this);
                        builder.setTitle(Html.fromHtml("<h4><b>Useful information</b></h4>"));
                        builder.setMessage(Html.fromHtml("<p>• To view available commands for a record <u>click</u> on it.</p>" +
                                "<p>• To view the available features for a record, <u>click and hold</u> on it.</p>" +
                                "<p>• To edit a record <u>click and hold</u> on it, then click on the edit button <font color=\"#00BFFF\">(the blue pen)</font>.<br>" +
                                "For the edit feature to be available you must select one record only.</p>" +
                                "<p>• To delete a record <u>click and hold</u> on it, then select the delete button <font color=\"#FF0000\">(the red recycle bin)</font>.<br>" +
                                "You can delete multiple records at a time, just select them.</p>"));
                        builder.show();
                    }
                }
        );
    }

    //Method to handle the activity when the back button, on the user device, is pressed
    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {

        //If "UsedActionMode" is "true", in other words, the action mode has been used
        if (UsedActionMode){
            //Initialize the intent to be the "MainActivity" class (the main menu of the app)
            Intent intent = new Intent(Contacts_Details_Activity.this, MainActivity.class);
            //Remove activities from the history stack (don't return to the previous activity when the user clicks on the back button on his device)
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            //Start the activity - go to the "MainActivity" class (the main menu of the app)
            startActivity(intent);
        }
        //If "UsedActionMode" is "false", in other words, the action mode has not been used
        else {
            //Finish the activity on which you were before clicking on the button
            finish();
        }
    }
}