package com.phonerecords;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.Html;
import android.text.TextWatcher;
import android.view.ActionMode;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.phonerecords.Adapter.DataAdapter;
import com.phonerecords.DataModel.Item_Database;

import java.util.ArrayList;

public class Edit_Contact_Activity extends AppCompatActivity {
    //Declare the variables that are needed
    EditText name,phone;
    DatabaseHelper myDb;
    Button edit_button;
    ImageButton return_menu_button, info_button;
    AlertDialog.Builder builder_for_choice;

    //Create the onCreate method (on "Edit_Contact_Activity" class startup)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_contact);
        //Initialize the variables and call needed methods on startup
        name = findViewById(R.id.editName);
        phone = findViewById(R.id.editPhone);
        edit_button = findViewById(R.id.edit_contact_button);
        return_menu_button = findViewById(R.id.return_button);
        info_button = findViewById(R.id.info_button);
        myDb = new DatabaseHelper(this);
        builder_for_choice = new AlertDialog.Builder(this);
        //Assign the value from the "getNameContact" method in the "DatabaseHelper" class, with the specified ID taken from "Contacts_Details_Activity.ID_for_record", in the "editName" EditText
        name.setText(myDb.getNameContact(Contacts_Details_Activity.ID_for_record));
        //Assign the value from the "getPhoneContact" method in the "DatabaseHelper" class, with the specified ID taken from "Contacts_Details_Activity.ID_for_record", in the "editPhone" EditText
        phone.setText(myDb.getPhoneContact(Contacts_Details_Activity.ID_for_record));
        //Initialize the initial parameters on the "edit_button"
        edit_button.setEnabled(false);
        edit_button.setBackgroundColor(getResources().getColor(android.R.color.background_dark));
        edit_button.setTextColor(getResources().getColor(android.R.color.darker_gray));
        //Call the needed methods on startup
        EditData();
        viewRules();

        //Create the method when the user clicks on the "return_button"
        return_menu_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //When "editName" or "editPhone" are not equal to the data from the contact which is to be edited, do the following...
                if (!name.getText().toString().equals(myDb.getNameContact(Contacts_Details_Activity.ID_for_record)) || !phone.getText().toString().equals(myDb.getPhoneContact(Contacts_Details_Activity.ID_for_record))){
                    //Create an alert dialog so the user can confirm his choice
                    builder_for_choice.setTitle("Caution");
                    builder_for_choice.setMessage("Exit without editing the contact?");
                    builder_for_choice.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        //What to do if the user confirms his choice (to exit the "Edit_Contact_Activity" without editing the contact)
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            //Initialize the intent to be the "Contacts_Details_Activity" class
                            Intent intent = new Intent(Edit_Contact_Activity.this, Contacts_Details_Activity.class);
                            //Remove activities from the history stack (don't return to the previous activity when the user clicks on the back button on his device)
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            //Start the activity - go to the "Contacts_Details_Activity" class
                            startActivity(intent);
                            //Set the "IsActionMode" boolean from "Contacts_Details_Activity" class to "false"
                            Contacts_Details_Activity.IsActionMode = false;
                            //Set the "UsedActionMode" boolean from "Contacts_Details_Activity" class to "true"
                            Contacts_Details_Activity.UsedActionMode = true;
                        }
                    });
                    builder_for_choice.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        //What to do if the user doesn't confirm his choice (to exit the "Edit_Contact_Activity" without editing the contact)
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            //Nothing to do here :-D
                        }
                    });
                    //Show the alert dialog via its built in method - "show()"
                    builder_for_choice.show();
                }
                //When "editName" or "editPhone" are equal to the data from the contact which is to be edited, do the following...
                else {
                    //Initialize the intent to be the "Contacts_Details_Activity" class
                    Intent intent = new Intent(Edit_Contact_Activity.this, Contacts_Details_Activity.class);
                    //Remove activities from the history stack (don't return to the previous activity when the user clicks on the back button on his device)
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    //Start the activity - go to the "Contacts_Details_Activity" class
                    startActivity(intent);
                    //Set the "IsActionMode" boolean from "Contacts_Details_Activity" class to "false"
                    Contacts_Details_Activity.IsActionMode = false;
                    //Set the "UsedActionMode" boolean from "Contacts_Details_Activity" class to "true"
                    Contacts_Details_Activity.UsedActionMode = true;
                }
            }
        });

        /*
        Declare and initialize a new "TextWatcher" and its method, to control when to enable or not the "edit_button", depending on the data
        that user types in the "editName" and "editPhone" text boxes
        */
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            //What to do when user changes text in the "textWatcher"
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                //If the typed data in the name and phone text fields matches the regex, do the following...
                if (name.getText().toString().matches("^\\S[\\p{L}\\p{N}_()\\s-]*[\\p{L}\\p{N}_()-]$") && phone.getText().toString().matches("^\\p{N}+$")) {
                    //When "editName" and "editPhone" are equal to the data from the contact which is to be edited, do the following...
                    if (name.getText().toString().equals(myDb.getNameContact(Contacts_Details_Activity.ID_for_record)) && phone.getText().toString().equals(myDb.getPhoneContact(Contacts_Details_Activity.ID_for_record))) {
                        //Disable the "edit_button"
                        edit_button.setEnabled(false);
                        //Change background color of the "edit_button"
                        edit_button.setBackgroundColor(getResources().getColor(android.R.color.background_dark));
                        //Change the color of the text on the "edit_button"
                        edit_button.setTextColor(getResources().getColor(android.R.color.darker_gray));
                    }
                    //When "editName" and "editPhone" are not equal to the data from the contact which is to be edited, do the following...
                    else {
                        //Enable the "edit_button"
                        edit_button.setEnabled(true);
                        //Change background color of the "edit_button"
                        edit_button.setBackgroundColor(getResources().getColor(R.color.bright_red));
                        //Change the color of the text on the "edit_button"
                        edit_button.setTextColor(getResources().getColor(R.color.white));
                    }
                }
                //If the typed data in the name and phone text fields doesn't match the regex, do the following...
                else {
                    //Disable the "edit_button"
                    edit_button.setEnabled(false);
                    //Change background color of the "edit_button"
                    edit_button.setBackgroundColor(getResources().getColor(android.R.color.background_dark));
                    //Change the color of the text on the "edit_button"
                    edit_button.setTextColor(getResources().getColor(android.R.color.darker_gray));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        };
        //Add the newly created "textWatcher" to the "addTextChangedListener()" method of the "editName" and "editPhone" text boxes
        name.addTextChangedListener(textWatcher);
        phone.addTextChangedListener(textWatcher);
    }

    //Create the method when user clicks on the edit button
    public void EditData() {
        edit_button.setOnClickListener(
                new View.OnClickListener() {
                    @SuppressLint("SuspiciousIndentation")
                    @Override
                    public void onClick(View v) {
                        //Confirm before we edit the call
                        builder_for_choice.setTitle("Caution");
                        builder_for_choice.setMessage("Are you sure you want to edit the contact?");
                        builder_for_choice.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            //What to do if the user confirms the editing of the contact
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //Set the boolean "isUpdated" to accept the value of the "updateRecord" method from the "DatabaseHelper" class, with the necessary arguments
                                boolean isUpdated = myDb.updateRecord(Contacts_Details_Activity.ID_for_record, name.getText().toString(), phone.getText().toString());
                                //If there aren't errors edit the chosen record in the database
                                if(isUpdated) {
                                    //Initialize the intent to be the "Contacts_Details_Activity" class
                                    Intent intent = new Intent(Edit_Contact_Activity.this, Contacts_Details_Activity.class);
                                    //Remove activities from the history stack
                                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                    //Start the activity - go to the "Contacts_Details_Activity" class
                                    startActivity(intent);
                                    //Override the pending transition between the activities
                                    overridePendingTransition(0, 0);
                                    //Set the "IsActionMode" boolean from "Contacts_Details_Activity" class to "false"
                                    Contacts_Details_Activity.IsActionMode = false;
                                    //Set the "UsedActionMode" boolean from "Contacts_Details_Activity" class to "true"
                                    Contacts_Details_Activity.UsedActionMode = true;
                                    Toast.makeText(Edit_Contact_Activity.this,"Contact Edited Successfully",Toast.LENGTH_SHORT).show();
                                }
                                //If there are errors don't edit the chosen record in the database
                                else {
                                    Toast.makeText(Edit_Contact_Activity.this, "Contact was not Edited", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                        builder_for_choice.setNegativeButton("No", new DialogInterface.OnClickListener() {
                            //Set what to do if the user cancels the editing of the contact
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                //Nothing to do here :-D
                            }
                        });
                        //Show the alert dialog via its built in method - "show()"
                        builder_for_choice.show();
                    }
                }
        );
    }

    //Create the method when the user clicks on the "info_button" to show him the rules of editing a record
    public void viewRules() {
        info_button.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(Edit_Contact_Activity.this);
                        builder.setTitle(Html.fromHtml("<h4><b>Rules for editing a record</b></h4>"));
                        builder.setMessage(Html.fromHtml("<p>• Name cannot <u>begin or end</u> with <u>whitespace</u>!<br>" +
                                "Use only special characters like: \"<b>-</b>\" , \"<b>_</b>\", \"<b>(</b>\", \"<b>)</b>\" !</p>" +
                                "<p>• Phone must contain <u>only digits</u> and no <u>whitespace</u>!</p>"));
                        builder.show();
                    }
                }
        );
    }

    //Method to handle the activity when the back button, on the user device, is pressed
    @SuppressLint("MissingSuperCall")
    @Override
    public void onBackPressed() {
        //When "editName" or "editPhone" are not equal to the data from the contact which is to be edited, do the following...
        if (!name.getText().toString().equals(myDb.getNameContact(Contacts_Details_Activity.ID_for_record)) || !phone.getText().toString().equals(myDb.getPhoneContact(Contacts_Details_Activity.ID_for_record))) {
            //Create an alert dialog so the user can confirm his choice
            builder_for_choice.setTitle("Caution");
            builder_for_choice.setMessage("Exit without editing the contact?");
            builder_for_choice.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                //What to do if the user confirms his choice (to exit the "Edit_Contact_Activity" without editing the contact)
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    //Initialize the intent to be the "Contacts_Details_Activity" class
                    Intent intent = new Intent(Edit_Contact_Activity.this, Contacts_Details_Activity.class);
                    //Remove activities from the history stack (don't return to the previous activity when the user clicks on the back button on his device)
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    //Start the activity - go to the "Contacts_Details_Activity" class
                    startActivity(intent);
                    //Set the "IsActionMode" boolean from "Contacts_Details_Activity" class to "false"
                    Contacts_Details_Activity.IsActionMode = false;
                    //Set the "UsedActionMode" boolean from "Contacts_Details_Activity" class to "true"
                    Contacts_Details_Activity.UsedActionMode = true;
                }
            });
            builder_for_choice.setNegativeButton("No", new DialogInterface.OnClickListener() {
                //What to do if the user doesn't confirm his choice (to exit the "Edit_Contact_Activity" without editing the contact)
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    //Nothing to do here :-D
                }
            });
            //Show the alert dialog via its built in method - "show()"
            builder_for_choice.show();
        }
        //When "editName" or "editPhone" are equal to the data from the contact which is to be edited, do the following...
        else {
            //Initialize the intent to be the "Contacts_Details_Activity" class
            Intent intent = new Intent(Edit_Contact_Activity.this, Contacts_Details_Activity.class);
            //Remove activities from the history stack (don't return to the previous activity when the user clicks on the back button on his device)
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            //Start the activity - go to the "Contacts_Details_Activity" class
            startActivity(intent);
            //Set the "IsActionMode" boolean from "Contacts_Details_Activity" class to "false"
            Contacts_Details_Activity.IsActionMode = false;
            //Set the "UsedActionMode" boolean from "Contacts_Details_Activity" class to "true"
            Contacts_Details_Activity.UsedActionMode = true;
        }
    }
}