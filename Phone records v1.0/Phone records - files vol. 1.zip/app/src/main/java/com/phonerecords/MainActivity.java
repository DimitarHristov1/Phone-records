package com.phonerecords;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.app.AlertDialog;
import android.text.Editable;
import android.text.Html;
import android.text.TextWatcher;
import android.view.inputmethod.InputMethodManager;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {
    //Declare the variables that are needed
    DatabaseHelper myDb;
    EditText name,phone;
    Button add_button, view_button;
    ImageButton info_button;

    //Create the onCreate method (on "MainActivity" class startup)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Initialize the variables needed on startup
        myDb = new DatabaseHelper(this);
        name = findViewById(R.id.editName);
        phone = findViewById(R.id.editPhone);
        add_button = findViewById(R.id.add_button);
        view_button = findViewById(R.id.view_button);
        info_button = findViewById(R.id.info_button);
        //Initialize the initial parameters on the "add_button"
        add_button.setEnabled(false);
        add_button.setBackgroundColor(getResources().getColor(android.R.color.background_dark));
        add_button.setTextColor(getResources().getColor(android.R.color.darker_gray));
        //Call the needed methods on startup
        AddData();
        viewAll();
        viewRules();

        /*
        Declare and initialize a new "TextWatcher" and its method, to control when to enable or not the "add_button", depending on the data
        that user types in the "editName" and "editPhone" text boxes
        */
        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            //What to do when user changes text in the "textWatcher"
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                //If the typed data in the name and phone text fields matches the regex, do the following...
                if (name.getText().toString().matches("^\\S[\\p{L}\\p{N}_()\\s-]*[\\p{L}\\p{N}_()-]$") && phone.getText().toString().matches("^\\p{N}+$")) {
                    //Enable the "add_button"
                    add_button.setEnabled(true);
                    //Change background color of the "add_button"
                    add_button.setBackgroundColor(getResources().getColor(R.color.green));
                    //Change the color of the text on the "add_button"
                    add_button.setTextColor(getResources().getColor(R.color.transparent));
                }
                //If the typed data in the name and phone text fields doesn't match the regex, do the following...
                else {
                    //Disable the "add_button"
                    add_button.setEnabled(false);
                    //Change background color of the "add_button"
                    add_button.setBackgroundColor(getResources().getColor(android.R.color.background_dark));
                    //Change the color of the text on the "add_button"
                    add_button.setTextColor(getResources().getColor(android.R.color.darker_gray));
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        };
        //Add the newly created "textWatcher" to the "addTextChangedListener()" method of the "editName" and "editPhone" text boxes
        name.addTextChangedListener(textWatcher);
        phone.addTextChangedListener(textWatcher);
    }

    //Create the method for inserting the data that is typed in the "editName" and "editPhone" text boxes by the user, into the database
    public void AddData() {
        add_button.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //Set the boolean "isInserted" to accept the value of the "insertData" method from the "DatabaseHelper" class, with the necessary arguments
                        boolean isInserted = myDb.insertData(name.getText().toString(), phone.getText().toString());
                        //If there aren't errors insert the new record to the database
                        if(isInserted) {
                            Toast.makeText(MainActivity.this,"Contact Inserted",Toast.LENGTH_SHORT).show();
                        }
                        //If there are errors don't insert the new record to the database
                        else {
                            Toast.makeText(MainActivity.this, "Contact was not Inserted", Toast.LENGTH_SHORT).show();
                        }
                        //Clear the data and the focus from the "editName" and "editPhone" text boxes
                        name.setText("");
                        name.clearFocus();
                        phone.setText("");
                        phone.clearFocus();
                    }
                }
        );
    }

    //Create the method when the user clicks on the button to show the contacts from the main page of the app
    public void viewAll() {
        view_button.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (myDb.getAllData().isEmpty()) {
                            showMessage("Error", "No data in contact list!");
                        }
                        else {
                            startActivity(new Intent(MainActivity.this, Contacts_Details_Activity.class));
                            //Set the "UsedActionMode" boolean from "Contacts_Details_Activity" class to "false"
                            Contacts_Details_Activity.UsedActionMode = false;
                        }
                    }
                }
        );
    }

    //Create the method when the user clicks on the "info_button" to show him the rules of adding a record
    public void viewRules() {
        info_button.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                        builder.setTitle(Html.fromHtml("<h4><b>Rules for adding a record</b></h4>"));
                        builder.setMessage(Html.fromHtml("<p>• Name cannot <u>begin or end</u> with <u>whitespace</u>!<br>" +
                                "Use only special characters like: \"<b>-</b>\" , \"<b>_</b>\", \"<b>(</b>\", \"<b>)</b>\" !</p>" +
                                "<p>• Phone must contain <u>only digits</u> and no <u>whitespace</u>!</p>"));
                        builder.show();
                    }
                }
        );
    }

    //Create the "showMessage" method to use when needed, which is a simple method for creating an alert dialog
    public void showMessage(String title,String Message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }
}